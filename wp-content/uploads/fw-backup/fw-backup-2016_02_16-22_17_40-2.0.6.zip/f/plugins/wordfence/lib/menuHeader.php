<?php if(wfConfig::get('cacheType') == 'falcon'){ ?>
<div title="Wordfence Falcon Engine Enabled for Maximum Site Performance" class="wfFalcon"></div>
<?php } ?>

